# TEOS Desktop v5.0.0
Requires Node 18+

Usage:
  Windows:  teos.cmd run "npm run build"
  Linux/macOS: ./teos run "npm run build"

Set TEOS_API_KEY (X-API-Key) before using CLI enforce.
API endpoint: https://sentinel.teosegypt.com
