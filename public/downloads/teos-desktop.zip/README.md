# TEOS Desktop v4.0.0
Requires Node 18+

teos.cmd run "npm run build"
