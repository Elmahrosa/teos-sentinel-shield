@echo off
set TEOS_API_URL=https://sentinel.teosegypt.com
node "%~dp0teos.js" %*
