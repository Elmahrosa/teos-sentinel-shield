TEOS TEOS Sentinel Shield (Edge) v4.0.0
Load unpacked from chrome://extensions or edge://extensions
