TEOS Sentinel Shield v5.0.0
Load unpacked from chrome://extensions or edge://extensions
API endpoint: https://sentinel.teosegypt.com (X-API-Key required)
