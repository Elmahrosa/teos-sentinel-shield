const API='https://sentinel.teosegypt.com';
const keyInput=document.getElementById('apikey');
keyInput.value=localStorage.getItem('teos_api_key')||'';
keyInput.onchange=()=>localStorage.setItem('teos_api_key',keyInput.value.trim());
document.getElementById('go').onclick=async()=>{
const cmd=document.getElementById('cmd').value.trim(),out=document.getElementById('out');
localStorage.setItem('teos_api_key',keyInput.value.trim());
if(!cmd){out.textContent='Enter a command';return;}
if(!keyInput.value.trim()){out.textContent='Enter your X-API-Key (get one via /api/version endpoint)';return;}
out.textContent='Scanning…';
try{const r=await fetch(API+'/scan',{method:'POST',headers:{'Content-Type':'application/json','X-API-Key':keyInput.value.trim()},body:JSON.stringify({command:cmd,type:'shell'})});
const j=await r.json();out.textContent=(j.verdict||r.status)+' score='+(j.score??'?')+'\n'+(j.rule||j.error||'');}
catch(e){out.textContent='API unreachable: '+e.message;}
};
