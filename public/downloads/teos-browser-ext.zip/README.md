TEOS TEOS Sentinel Shield v4.0.0
Load unpacked from chrome://extensions or edge://extensions
