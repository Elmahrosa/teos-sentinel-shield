const API='https://teos-sentinel-shield-production-ef7a.up.railway.app';
document.getElementById('go').onclick=async()=>{
const cmd=document.getElementById('cmd').value.trim(),out=document.getElementById('out');
if(!cmd){out.textContent='Enter a command';return;}
out.textContent='Scanning…';
try{const r=await fetch(API+'/scan',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({command:cmd,type:'shell'})});
const j=await r.json();out.textContent=(j.verdict||r.status)+' score='+(j.score??'?')+'\n'+(j.rule||j.error||'');}
catch(e){out.textContent='API unreachable: '+e.message;}
};