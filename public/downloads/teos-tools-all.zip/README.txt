TEOS Sentinel Tools Bundle v4.0.0 GA
Site: https://sentinel.teosegypt.com

Contents:
  teos-desktop.zip
  teos-browser-ext.zip
  teos-browser-ext-edge.zip
  teos-vscode-ext.vsix
  teos.js

Set TEOS_API_KEY before using CLI enforce.