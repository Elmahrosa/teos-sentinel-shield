TEOS Sentinel Tools Bundle v5.0.0 GA
Site: https://sentinel.teosegypt.com

Contents:
  teos.js (CLI)
  teos-desktop.zip
  teos-browser-ext.zip
  teos-browser-ext-edge.zip
  teos-vscode-ext.vsix

Set TEOS_API_KEY before using CLI enforce.
API endpoint: https://sentinel.teosegypt.com
